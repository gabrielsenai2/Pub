package br.senai.service;

import br.senai.model.Cliente;

import java.util.List;

public interface UsuarioService {

    public List<Cliente> findAll();
    public Cliente findByNome(String nome);
    public Cliente findByEmail(String email);
    public Cliente findBySenha(double senha);

}
